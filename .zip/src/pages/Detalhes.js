import { useParams } from 'react-router-dom';
import Detalhe from './../components/Detalhe/detalhe';


const Detalhes = () => {
  
  const { movie } = useParams();

  return <Detalhe movie={movie} />;
};


export default Detalhes;